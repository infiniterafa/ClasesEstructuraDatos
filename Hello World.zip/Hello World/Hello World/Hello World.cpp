

//int main()
//{
//  std::cout << "Hello World!\n";
//}

#include<iostream>

int main(int argc, char** argv)
{

	std::cout << "Hola Mundo" << std::endl;
	return 0;
}
